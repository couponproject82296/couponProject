// Bootstrap
angular.module("myApp", ['ui.router','ngAnimate']) ;

