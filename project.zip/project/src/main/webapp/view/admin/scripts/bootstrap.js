// Bootstrap

angular.module('myApp', ['ui.router','cp.ngConfirm','ngAnimate']);